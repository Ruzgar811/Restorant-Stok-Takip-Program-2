Restaurant Stock Tracking - Basit Konsol Uygulaması

Kullanım:
1. Terminalde RestaurantStockApp klasörüne gidin.
2. dotnet run komutunu çalıştırın.

Özellikler:
- Ürün ekleme, silme, listeleme
- Miktar güncelleme
- Veriler inventory.json dosyasında saklanır

Geliştirme önerileri:
- Fiyat hesapları ve raporlama ekleyin
- Basit GUI (WinForms/WPF) veya web arayüzü ekleyin
- Birim testleri ekleyin
