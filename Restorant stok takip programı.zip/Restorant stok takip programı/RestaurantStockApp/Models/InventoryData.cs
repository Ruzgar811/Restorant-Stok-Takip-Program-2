using System.Text.Json.Serialization;

namespace RestaurantStockApp.Models
{
    public class InventoryData
    {
        [JsonInclude]
        public List<Product> Products { get; set; } = new();

        [JsonInclude]
        public List<string> Categories { get; set; } = new();
    }
}
